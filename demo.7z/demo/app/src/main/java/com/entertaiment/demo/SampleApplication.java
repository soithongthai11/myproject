package com.entertaiment.demo;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

import com.entertaiment.demo.commonbase.BaseApplication;
import com.entertaiment.demo.utils.Constraints;

public class SampleApplication extends BaseApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
