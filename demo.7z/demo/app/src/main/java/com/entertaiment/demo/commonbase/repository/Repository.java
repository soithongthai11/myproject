package com.entertaiment.demo.commonbase.repository;

public interface Repository {

}
